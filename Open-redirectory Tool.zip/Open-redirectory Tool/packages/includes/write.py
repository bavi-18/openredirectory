def write_output(file_name, results):
    with open(file_name, 'w') as file:
        for result in results:
            file.write(result + '\n')
