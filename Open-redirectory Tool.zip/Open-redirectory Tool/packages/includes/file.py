def read_input_file(file_name):
    with open(file_name, 'r') as file:
        urls = [line.strip() for line in file if line.strip()]
    return urls
