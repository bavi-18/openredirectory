import re
from urllib.parse import urlparse, parse_qs

def scan_url(url):
    # Parsing the URL
    parsed_url = urlparse(url)
    query_params = parse_qs(parsed_url.query)

    # Patterns for detecting open redirect vulnerabilities
    open_redirect_keywords = ['redirect', 'redir', 'url', 'forward']

    for param in query_params:
        # Check if any query parameter contains a typical open redirect keyword
        if any(keyword in param.lower() for keyword in open_redirect_keywords):
            # Check the value of the parameter to see if it's a URL
            param_value = query_params[param][0]
            if param_value.startswith('http://') or param_value.startswith('https://'):
                return f"Potential Open Redirect found in parameter '{param}' with value '{param_value}'"
    
    return "No open redirect detected"
