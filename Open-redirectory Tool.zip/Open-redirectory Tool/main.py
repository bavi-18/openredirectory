import argparse
import requests
from units.banner import display_banner
from units.chknet import check_network
from packages.includes.file import read_input_file
from packages.includes.scan import scan_url
from packages.includes.write import write_output
from units.urls import BLOG_URL

def main():
    parser = argparse.ArgumentParser(description="Open Redirect Bug Finder Tool")
    parser.add_argument('-u', '--url', help='URL to scan for open redirect vulnerabilities', type=str)
    parser.add_argument('-i', '--input', help='Input file name to read URLs from', type=str)
    parser.add_argument('-o', '--output', help='Output file name to save the scan results', type=str)
    parser.add_argument('-b', '--blog', help='Opens the specified blog URL in the browser', action='store_true')

    args = parser.parse_args()

    # Display banner
    display_banner()

    # Check network
    if not check_network():
        print("No internet connection. Please check your connection and try again.")
        return

    urls_to_scan = []

    if args.url:
        urls_to_scan.append(args.url)
    if args.input:
        urls_to_scan.extend(read_input_file(args.input))

    results = []
    for url in urls_to_scan:
        result = scan_url(url)
        results.append(result)
        print(f"Scanned URL: {url} \n\n Result: {result}")

    if args.output:
        write_output(args.output, results)

    if args.blog:
        import webbrowser
        webbrowser.open(BLOG_URL)

if __name__ == "__main__":
    main()
