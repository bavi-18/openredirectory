BLOG_URL = "http://example.com/blog"
