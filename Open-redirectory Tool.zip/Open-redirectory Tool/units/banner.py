from termcolor import colored

def display_banner():
    # Displaying the banner with colors
    print(colored("""
 ██╗███╗   ██╗████████╗███████╗██████╗ ██╗███████╗
 ██║████╗  ██║╚══██╔══╝██╔════╝██╔══██╗██║██╔════╝
 ██║██╔██╗ ██║   ██║   █████╗  ██████╔╝██║███████╗
 ██║██║╚██╗██║   ██║   ██╔══╝  ██╔══██╗██║╚════██║
 ██║██║ ╚████║   ██║   ███████╗██║  ██║██║███████║
 ╚═╝╚═╝  ╚═══╝   ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝╚══════╝
                                                    
    """, 'cyan'))

    # Additional information
    info = """
**************************************************
*                                                *
*            OPEN REDIRECT SCANNER               *
*                                                *
**************************************************
*  Author: Bavis                                 *
*  Version: 1.0                                  *
*  Description: This tool helps in finding open  *
*  redirect vulnerabilities in web applications. *
*                                                *
**************************************************
"""
    print(colored(info, 'grey'))

if __name__ == "__main__":
    display_banner()
    # Your main script logic here
